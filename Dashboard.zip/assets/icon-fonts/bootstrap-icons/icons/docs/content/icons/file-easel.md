---
title: File easel
categories:
  - Files and folders
tags:
  - slides
  - presentation
  - powerpoint
  - keynote
---
