---
title: Cone
categories:
  - Real world
tags:
  - construction
  - warning
  - safety
---
