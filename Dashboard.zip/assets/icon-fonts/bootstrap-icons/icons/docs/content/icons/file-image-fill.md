---
title: File image fill
categories:
  - Files and folders
tags:
  - photo
  - picture
---
