---
title: Emoji expressionless fill
categories:
  - Emoji
tags:
  - emoticon
  - neutral
  - unphased
---
