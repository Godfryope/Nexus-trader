---
title: File binary
categories:
  - Files and folders
tags:
  - doc
  - document
  - binary
  - source
---
