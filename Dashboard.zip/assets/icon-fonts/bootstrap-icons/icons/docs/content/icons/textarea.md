---
title: Textarea
categories:
  - Graphics
tags:
  - text
  - insert
  - bounding-box
---
