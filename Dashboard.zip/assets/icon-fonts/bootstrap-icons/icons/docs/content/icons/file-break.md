---
title: File break
categories:
  - Files and folders
tags:
  - doc
  - document
  - page-break
---
