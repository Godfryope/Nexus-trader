---
title: CPU
categories:
  - Devices
tags:
  - processor
  - chip
  - computer
---
