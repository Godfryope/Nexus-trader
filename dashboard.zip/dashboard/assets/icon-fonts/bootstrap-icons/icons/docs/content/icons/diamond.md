---
title: Diamond
categories:
  - Shapes
tags:
  - shape
---
