---
title: Text center
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
---
