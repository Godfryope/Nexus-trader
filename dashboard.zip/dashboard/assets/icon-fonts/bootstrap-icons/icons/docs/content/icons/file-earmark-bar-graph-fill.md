---
title: File earmark bar graph fill
categories:
  - Files and folders
tags:
  - doc
  - document
  - data
  - chart
---
