---
title: File earmark bar graph
categories:
  - Files and folders
tags:
  - doc
  - document
  - data
  - chart
---
