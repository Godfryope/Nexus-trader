---
title: Device SSD
categories:
  - Devices
tags:
  - "solid state"
  - drive
---
