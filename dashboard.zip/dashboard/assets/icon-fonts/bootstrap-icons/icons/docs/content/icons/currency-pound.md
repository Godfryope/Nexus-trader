---
title: Currency pound
categories:
  - Commerce
tags:
  - money
  - finance
---
