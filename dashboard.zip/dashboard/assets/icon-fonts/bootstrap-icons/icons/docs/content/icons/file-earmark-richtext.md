---
title: File earmark richtext
categories:
  - Files and folders
tags:
  - text
  - doc
  - document
---
