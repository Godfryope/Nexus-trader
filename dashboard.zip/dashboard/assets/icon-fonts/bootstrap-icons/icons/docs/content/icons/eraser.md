---
title: Eraser
categories:
  - Graphics
tags:
  - erase
  - remove
---
