---
title: Emoji heart eyes fill
categories:
  - Emoji
tags:
  - emoticon
  - heart
  - love
---
