---
title: File earmark lock2
categories:
  - Files and folders
tags:
  - lock
  - private
  - secure
---
