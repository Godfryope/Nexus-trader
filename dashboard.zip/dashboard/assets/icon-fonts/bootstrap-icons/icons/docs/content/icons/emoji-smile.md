---
title: Emoji smile
categories:
  - Emoji
tags:
  - emoticon
  - happy
---
