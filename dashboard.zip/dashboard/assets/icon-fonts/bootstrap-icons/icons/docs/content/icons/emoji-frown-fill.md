---
title: Emoji frown fill
categories:
  - Emoji
tags:
  - emoticon
  - sad
---
